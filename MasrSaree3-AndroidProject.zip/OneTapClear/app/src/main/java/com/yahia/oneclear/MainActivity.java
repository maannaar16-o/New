package com.yahia.oneclear;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

    private TextView statusView;
    private final List<CheckBox> appBoxes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        root.addView(title("مسح سريع للحسابات"));
        root.addView(body("بضغطة واحدة، التطبيق بيفتح إعدادات كل تطبيق اخترته ويضغط «مسح البيانات» "
                + "تلقائيًا، فتتسجّل خروج من حساباتك بسرعة.\n"
                + "⚠️ مسح البيانات بيمسح المحادثات المحلية (واتساب/تليجرام/سجنال) وبيطلب تسجيل دخول من جديد."));

        statusView = body("");
        root.addView(statusView);

        Button enableBtn = button("① تفعيل خدمة الوصول (Accessibility)");
        enableBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (Exception ignored) {}
            }
        });
        root.addView(enableBtn);

        Button overlayBtn = button("② السماح بالعرض فوق التطبيقات");
        overlayBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
                    } catch (Exception ignored) {}
                }
            }
        });
        root.addView(overlayBtn);

        final CheckBox confirmBox = new CheckBox(this);
        confirmBox.setText("اطلب تأكيد قبل المسح (للأمان)");
        confirmBox.setChecked(Prefs.isConfirmEnabled(this));
        confirmBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton bv, boolean checked) {
                Prefs.setConfirmEnabled(MainActivity.this, checked);
            }
        });
        root.addView(space(dp(8)));
        root.addView(confirmBox);

        Button clearBtn = button("امسح الآن");
        clearBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        clearBtn.setTextColor(Color.WHITE);
        clearBtn.setBackgroundColor(0xFFC62828);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(64));
        clp.topMargin = dp(14);
        clp.bottomMargin = dp(10);
        clearBtn.setLayoutParams(clp);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                ClearFlow.start(MainActivity.this, false);
            }
        });
        root.addView(clearBtn);

        root.addView(title2("اختر التطبيقات اللي تتمسح بياناتها:"));
        buildAppList(root);

        root.addView(space(dp(12)));
        root.addView(body("للـ«ضغطة واحدة» الحقيقية: اضغط مطوّلًا على الشاشة الرئيسية ← الودجتس (Widgets) "
                + "← اختر «مسح سريع» وحطّه على الشاشة. أي ضغطة عليه هتبدأ المسح فورًا."));

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean acc = ClearFlow.isAccessibilityEnabled(this);
        boolean ovl = ClearFlow.canDrawOverlays(this);
        StringBuilder s = new StringBuilder();
        s.append(acc ? "✔ خدمة الوصول: مفعّلة\n" : "✖ خدمة الوصول: غير مفعّلة (دوس زر ①)\n");
        s.append(ovl ? "✔ العرض فوق التطبيقات: مسموح"
                     : "✖ العرض فوق التطبيقات: غير مسموح (مطلوب للمسح المتتابع — زر ②)");
        if (!ClearState.running.get() && ClearState.totalCount > 0 && ClearState.currentPackage == null) {
            s.append("\n— آخر عملية: تم مسح ").append(ClearState.cleared.size())
                    .append("، وتعذّر ").append(ClearState.skipped.size());
        }
        statusView.setText(s.toString());
    }

    private void buildAppList(LinearLayout root) {
        appBoxes.clear();
        PackageManager pm = getPackageManager();
        final Set<String> selected = Prefs.getSelected(this);

        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(main, 0);

        Map<String, String> pkgToLabel = new LinkedHashMap<>();
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg == null || pkg.equals(getPackageName())) continue;
            if (!pkgToLabel.containsKey(pkg)) {
                CharSequence lbl = ri.loadLabel(pm);
                pkgToLabel.put(pkg, lbl == null ? pkg : lbl.toString());
            }
        }
        for (String p : selected) {
            if (!pkgToLabel.containsKey(p) && ClearFlow.isInstalled(pm, p)) {
                pkgToLabel.put(p, p);
            }
        }

        List<Map.Entry<String, String>> entries = new ArrayList<>(pkgToLabel.entrySet());
        Collections.sort(entries, new Comparator<Map.Entry<String, String>>() {
            public int compare(Map.Entry<String, String> a, Map.Entry<String, String> b) {
                boolean sa = selected.contains(a.getKey());
                boolean sb = selected.contains(b.getKey());
                if (sa != sb) return sa ? -1 : 1;
                return a.getValue().compareToIgnoreCase(b.getValue());
            }
        });

        for (Map.Entry<String, String> e : entries) {
            final String pkg = e.getKey();
            CheckBox cb = new CheckBox(this);
            cb.setText(e.getValue() + "  (" + pkg + ")");
            cb.setChecked(selected.contains(pkg));
            cb.setTag(pkg);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton bv, boolean checked) {
                    saveSelection();
                }
            });
            appBoxes.add(cb);
            root.addView(cb);
        }
    }

    private void saveSelection() {
        Set<String> sel = new HashSet<>();
        for (CheckBox cb : appBoxes) {
            if (cb.isChecked()) sel.add((String) cb.getTag());
        }
        Prefs.setSelected(this, sel);
    }

    // ---- small UI helpers ----
    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics());
    }

    private TextView title(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, 0, 0, dp(8));
        return tv;
    }

    private TextView title2(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(10), 0, dp(4));
        return tv;
    }

    private TextView body(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        tv.setPadding(0, dp(4), 0, dp(4));
        return tv;
    }

    private Button button(String t) {
        Button btn = new Button(this);
        btn.setText(t);
        btn.setAllCaps(false);
        return btn;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h));
        return v;
    }
}
