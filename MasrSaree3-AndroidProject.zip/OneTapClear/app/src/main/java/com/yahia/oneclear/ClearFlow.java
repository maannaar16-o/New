package com.yahia.oneclear;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** The shared "start clearing" flow used by both the in-app button and the widget. */
public final class ClearFlow {
    private ClearFlow() {}

    public static void start(final Activity a, final boolean finishAfter) {
        Set<String> sel = Prefs.getSelected(a);
        PackageManager pm = a.getPackageManager();
        final List<String> list = new ArrayList<>();
        for (String p : sel) {
            if (isInstalled(pm, p)) list.add(p);
        }

        if (list.isEmpty()) {
            Toast.makeText(a, "مفيش تطبيقات مختارة أو مثبتة. افتح التطبيق واختر التطبيقات.",
                    Toast.LENGTH_LONG).show();
            finishIf(a, finishAfter);
            return;
        }

        if (!isAccessibilityEnabled(a)) {
            Toast.makeText(a, "لازم تفعّل خدمة الوصول (Accessibility) الأول.", Toast.LENGTH_LONG).show();
            openAccessibilitySettings(a);
            finishIf(a, finishAfter);
            return;
        }

        if (Prefs.isConfirmEnabled(a)) {
            AlertDialog dlg = new AlertDialog.Builder(a)
                    .setTitle("تأكيد المسح")
                    .setMessage("هيتم مسح بيانات " + list.size() + " تطبيق.\n"
                            + "ده هيخرجك من الحسابات ويمسح المحادثات المحلية (واتساب/تليجرام/سجنال)، "
                            + "وهتحتاج تسجّل دخول من جديد. تمام؟")
                    .setPositiveButton("نعم، امسح", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            launch(a, list);
                            finishIf(a, finishAfter);
                        }
                    })
                    .setNegativeButton("إلغاء", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            finishIf(a, finishAfter);
                        }
                    })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        public void onCancel(DialogInterface d) {
                            finishIf(a, finishAfter);
                        }
                    })
                    .create();
            dlg.show();
        } else {
            launch(a, list);
            finishIf(a, finishAfter);
        }
    }

    private static void launch(Activity a, List<String> list) {
        ClearAccessibilityService svc = ClearAccessibilityService.instance;
        if (svc == null) {
            Toast.makeText(a, "الخدمة مش متصلة. افتح التطبيق وفعّل خدمة الوصول.", Toast.LENGTH_LONG).show();
            openAccessibilitySettings(a);
            return;
        }
        if (list.size() > 1 && !canDrawOverlays(a)) {
            Toast.makeText(a, "نصيحة: فعّل «العرض فوق التطبيقات» عشان يمسح كل التطبيقات بالتتابع.",
                    Toast.LENGTH_LONG).show();
        }
        Toast.makeText(a, "جارٍ المسح… سيب الجهاز لحد ما يخلّص", Toast.LENGTH_SHORT).show();
        svc.startQueue(list);
    }

    private static void openAccessibilitySettings(Activity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) {}
    }

    private static void finishIf(Activity a, boolean finishAfter) {
        if (finishAfter && !a.isFinishing()) a.finish();
    }

    static boolean isInstalled(PackageManager pm, String pkg) {
        try {
            pm.getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean canDrawOverlays(Context c) {
        try {
            return Settings.canDrawOverlays(c);
        } catch (Exception e) {
            return false;
        }
    }

    static boolean isAccessibilityEnabled(Context c) {
        if (ClearAccessibilityService.instance != null) return true;
        try {
            String flat = Settings.Secure.getString(c.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (flat == null || flat.isEmpty()) return false;
            String comp = c.getPackageName() + "/" + ClearAccessibilityService.class.getName();
            return flat.contains(comp) || flat.contains(c.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }
}
