package com.yahia.oneclear;

import android.app.Activity;
import android.os.Bundle;

/** Invisible activity launched by the home-screen widget (or a shortcut). */
public class TriggerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ClearFlow.start(this, true);
    }
}
