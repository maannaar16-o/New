package com.yahia.oneclear;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** Shared state between the trigger (activity/widget) and the accessibility service. */
public final class ClearState {
    private ClearState() {}

    public static final AtomicBoolean running = new AtomicBoolean(false);

    public static final List<String> queue = new ArrayList<>();
    public static final List<String> cleared = new ArrayList<>();
    public static final List<String> skipped = new ArrayList<>();

    public static volatile int totalCount = 0;
    public static volatile int doneCount = 0;
    public static volatile String currentPackage = null;

    public static synchronized void reset(List<String> pkgs) {
        queue.clear();
        queue.addAll(pkgs);
        cleared.clear();
        skipped.clear();
        totalCount = pkgs.size();
        doneCount = 0;
        currentPackage = null;
        running.set(true);
    }
}
