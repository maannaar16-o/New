package com.yahia.oneclear;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.LinkedHashSet;
import java.util.Set;

/** Stores which app packages to clear, plus the "ask before clearing" flag. */
public final class Prefs {
    private static final String FILE = "onetapclear";
    private static final String KEY_SELECTED = "selected_packages";
    private static final String KEY_CONFIRM = "confirm_before_clear";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static Set<String> getSelected(Context c) {
        Set<String> stored = sp(c).getStringSet(KEY_SELECTED, null);
        if (stored == null) return defaultSelection();
        return new LinkedHashSet<>(stored);
    }

    public static void setSelected(Context c, Set<String> pkgs) {
        sp(c).edit().putStringSet(KEY_SELECTED, new LinkedHashSet<>(pkgs)).apply();
    }

    public static boolean isConfirmEnabled(Context c) {
        return sp(c).getBoolean(KEY_CONFIRM, true);
    }

    public static void setConfirmEnabled(Context c, boolean v) {
        sp(c).edit().putBoolean(KEY_CONFIRM, v).apply();
    }

    /** Default targets: WhatsApp, Instagram, Facebook, Telegram, Signal. */
    public static Set<String> defaultSelection() {
        Set<String> s = new LinkedHashSet<>();
        s.add("com.whatsapp");
        s.add("com.instagram.android");
        s.add("com.facebook.katana");
        s.add("org.telegram.messenger");
        s.add("org.thoughtcrime.securesms");
        return s;
    }
}
