package com.yahia.oneclear;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/**
 * Drives the Settings UI to clear each selected app's data, one app after another.
 * It works by repeatedly inspecting the current screen ("ticks") and clicking:
 *   1) the "Storage" row (if needed)  ->  2) "Clear data"/"Clear storage"  ->  3) the confirm button.
 *
 * If some app is not cleared on your phone, the button text is probably different.
 * Add the exact words shown on your device to the arrays below (STORAGE_NAV / CLEAR_DATA / CONFIRM).
 */
public class ClearAccessibilityService extends AccessibilityService {

    public static ClearAccessibilityService instance;

    private static final int STEP_IDLE = 0;
    private static final int STEP_FIND = 1;
    private static final int STEP_CONFIRM = 2;

    private static final long PACKAGE_TIMEOUT_MS = 9000;
    private static final long CONFIRM_WAIT_MS = 4500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int step = STEP_IDLE;
    private int navClicks = 0;
    private int confirmClicks = 0;
    private long enterConfirmAt = 0;
    private long packageStartAt = 0;
    private int tickToken = 0;

    // ===== Button/row labels. Lower-case. Arabic + English + common variants. =====
    // Rows that open the Storage screen:
    private static final String[] STORAGE_NAV = {
            "storage & cache", "storage and cache", "storage usage", "storage",
            "التخزين والذاكرة المؤقتة", "التخزين والذاكرة", "وحدة التخزين",
            "مساحة التخزين", "استخدام وحدة التخزين", "التخزين"
    };
    // The button that actually clears the data:
    private static final String[] CLEAR_DATA = {
            "clear data", "clear storage", "clear all data", "delete data", "erase data",
            "مسح البيانات", "مسح بيانات", "محو البيانات", "حذف البيانات",
            "مسح مساحة التخزين", "مسح وحدة التخزين", "إفراغ مساحة التخزين", "مسح كل البيانات"
    };
    // Never treat these as "clear data" (they only clear cache):
    private static final String[] CACHE_EXCLUDE = {
            "cache", "الذاكرة المؤقتة", "المؤقتة", "المؤقت", "التخزين المؤقت", "الكاش"
    };
    // Affirmative button in the confirmation dialog:
    private static final String[] CONFIRM = {
            "delete", "ok", "okay", "yes", "erase", "clear all data",
            "حذف", "موافق", "نعم", "تم", "مسح كل البيانات", "حذف البيانات", "إزالة", "متابعة"
    };
    // Never click these in the dialog:
    private static final String[] CANCEL_EXCLUDE = {
            "cancel", "إلغاء", "الغاء", "لا،", "later"
    };
    // ================================================================================

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Progress is driven by timed ticks (see tick()); nothing needed here.
    }

    @Override
    public void onInterrupt() { }

    /** Entry point called from the app/widget to start clearing the given packages. */
    public void startQueue(List<String> packages) {
        ClearState.reset(packages);
        beginNextPackage();
    }

    private void beginNextPackage() {
        String pkg;
        synchronized (ClearState.class) {
            if (ClearState.queue.isEmpty()) {
                finishAll();
                return;
            }
            pkg = ClearState.queue.remove(0);
            ClearState.currentPackage = pkg;
        }
        navClicks = 0;
        confirmClicks = 0;
        step = STEP_FIND;
        packageStartAt = System.currentTimeMillis();
        enterConfirmAt = 0;
        openAppSettings(pkg);
        scheduleTick(900);
    }

    private void markClearedAndNext() {
        if (ClearState.currentPackage != null) ClearState.cleared.add(ClearState.currentPackage);
        ClearState.doneCount++;
        beginNextPackage();
    }

    private void markSkippedAndNext() {
        if (ClearState.currentPackage != null) ClearState.skipped.add(ClearState.currentPackage);
        ClearState.doneCount++;
        beginNextPackage();
    }

    private void scheduleTick(long delayMs) {
        final int token = ++tickToken;
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (token != tickToken) return; // superseded
                tick();
            }
        }, delayMs);
    }

    private void tick() {
        if (!ClearState.running.get()) { step = STEP_IDLE; return; }

        long now = System.currentTimeMillis();
        if (now - packageStartAt > PACKAGE_TIMEOUT_MS) {
            markSkippedAndNext();
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) { scheduleTick(500); return; }

        CharSequence pkgName = root.getPackageName();
        if (pkgName != null && getPackageName().contentEquals(pkgName)) {
            // Still on our own screen; wait for the Settings screen to appear.
            scheduleTick(400);
            return;
        }

        if (step == STEP_FIND) {
            AccessibilityNodeInfo clear = findClickableByLabels(root, CLEAR_DATA, CACHE_EXCLUDE);
            if (clear != null) {
                click(clear);
                step = STEP_CONFIRM;
                confirmClicks = 0;
                enterConfirmAt = now;
                scheduleTick(1000);
                return;
            }
            AccessibilityNodeInfo nav = findClickableByLabels(root, STORAGE_NAV, null);
            if (nav != null && navClicks < 3) {
                click(nav);
                navClicks++;
                scheduleTick(1000);
                return;
            }
            scheduleTick(500);
            return;
        }

        if (step == STEP_CONFIRM) {
            AccessibilityNodeInfo conf = findClickableByLabels(root, CONFIRM, CANCEL_EXCLUDE);
            if (conf != null) {
                click(conf);
                confirmClicks++;
                scheduleTick(1000);
                return;
            }
            if (confirmClicks >= 1) {
                markClearedAndNext();
                return;
            }
            if (now - enterConfirmAt > CONFIRM_WAIT_MS) {
                markSkippedAndNext();
                return;
            }
            scheduleTick(500);
            return;
        }

        scheduleTick(500);
    }

    private void openAppSettings(String pkg) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK
                    | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
        } catch (Exception ignored) {}
    }

    private void finishAll() {
        step = STEP_IDLE;
        ClearState.currentPackage = null;
        ClearState.running.set(false);
        final int c = ClearState.cleared.size();
        final int s = ClearState.skipped.size();
        handler.post(new Runnable() {
            @Override public void run() {
                String msg = (s == 0)
                        ? ("تم مسح بيانات " + c + " تطبيق ✔")
                        : ("تم مسح " + c + " تطبيق، وتعذّر " + s + " (جرّب تاني أو افتحه يدويًا)");
                Toast.makeText(ClearAccessibilityService.this, msg, Toast.LENGTH_LONG).show();
                try {
                    Intent i = new Intent(ClearAccessibilityService.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                    startActivity(i);
                } catch (Exception ignored) {}
            }
        });
    }

    // ---- screen scanning helpers ----

    private AccessibilityNodeInfo findClickableByLabels(AccessibilityNodeInfo node,
                                                        String[] labels, String[] excludes) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        String hay = ((t == null ? "" : t) + " " + (d == null ? "" : d))
                .toLowerCase(Locale.ROOT).trim();
        if (!hay.isEmpty() && matches(hay, labels, excludes)) {
            AccessibilityNodeInfo click = clickableSelfOrAncestor(node);
            if (click != null) return click;
        }
        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo r = findClickableByLabels(child, labels, excludes);
            if (r != null) return r;
        }
        return null;
    }

    private boolean matches(String hay, String[] labels, String[] excludes) {
        if (excludes != null) {
            for (String ex : excludes) {
                if (hay.contains(ex.toLowerCase(Locale.ROOT))) return false;
            }
        }
        for (String lb : labels) {
            if (hay.contains(lb.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private AccessibilityNodeInfo clickableSelfOrAncestor(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo cur = n;
        int guard = 0;
        while (cur != null && guard++ < 12) {
            if (cur.isClickable() && cur.isEnabled()) return cur;
            cur = cur.getParent();
        }
        return null;
    }

    private boolean click(AccessibilityNodeInfo n) {
        return n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }
}
